USE sakila;

-- Which actors have the first name ‘Scarlett’?
SELECT *
FROM actor
WHERE first_name = 'Scarlett';

-- Which actors have the last name ‘Johansson’?
SELECT *
FROM actor
WHERE last_name = 'Johansson';

-- Display the first and last names of all actors from the table actor.
SELECT first_name, last_name
FROM actor;

-- Display the first and last name of each actor in a single column in upper case letters.
SELECT UPPER(CONCAT(first_name, ' ', last_name)) AS full_name
FROM actor;

-- You need to find the ID number, first name, and last name of an actor, of whom you know only the first name, "Joe." What is one query would you use to obtain this information?
SELECT actor_id, first_name, last_name
FROM actor
WHERE first_name = 'Joe';

-- Find all actors whose last name contains the letters GEN.
SELECT *
FROM actor
WHERE last_name LIKE '%GEN%';

-- Find all actors whose last names contain the letters LI. This time, order the rows by last name and first name, in that order.
SELECT *
FROM actor
WHERE last_name LIKE '%LI%'
ORDER BY last_name, first_name;

-- Using IN, display the country_id and country columns of the following countries: Afghanistan, Bangladesh, and China.
SELECT country_id, country
FROM country
WHERE country IN ('Afghanistan', 'Bangladesh', 'China');
