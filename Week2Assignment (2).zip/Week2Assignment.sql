USE sakila;

-- 1.Use JOIN to display the first and last names, as well as the address, of each staff member. Use the tables staff and address.
SELECT s.first_name, s.last_name, a.address
FROM staff s
JOIN address a ON s.address_id = a.address_id;

-- 2.Use JOIN to display the total amount rung up by each staff member in August of 2005.Use tables staff and payment.
SELECT s.staff_id, s.first_name, s.last_name, SUM(p.amount) AS 'Total Amount'
FROM staff s
JOIN payment p 
ON s.staff_id = p.staff_id
WHERE p.payment_date BETWEEN '2005-08-01' AND '2005-08-31'
GROUP BY s.staff_id, s.first_name, s.last_name;

-- 3.List each film and the number of actors who are listed for that film. Use tables film_actor and film. Use inner join.
SELECT f.title AS Title, GROUP_CONCAT(fa.actor_id) AS 'Actor IDs', COUNT(fa.actor_id) AS 'Number of actors'
FROM film f
INNER JOIN film_actor fa ON f.film_id = fa.film_id
GROUP BY f.film_id, f.title;

-- 4.How many copies of the film 'Hunchback Impossible' exist in the inventory system?
SELECT f.title AS Title, COUNT(*) AS 'Number of copies'
FROM inventory i
JOIN film f ON i.film_id = f.film_id
WHERE f.title = 'Hunchback Impossible';

-- 5.•	Using the tables payment and customer and the JOIN command, list the total paid by each customer. List the customers alphabetically by last name:
SELECT c.customer_id AS 'Customer ID', c.last_name AS 'Last Name', c.first_name AS 'First Name', SUM(p.amount) AS 'Total Paid'
FROM customer c
JOIN payment p ON c.customer_id = p.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY c.last_name, c.first_name;

-- 6.Use subqueries to display the titles of movies starting with the letters K and Q whose language is English.
SELECT film_id AS 'Film ID', title AS 'Title'
FROM film
WHERE (title LIKE 'K%' OR title LIKE 'Q%')
AND language_id = (SELECT language_id FROM language WHERE name = 'English');

-- 7. •	Use subqueries to display all actors who appear in the film Alone Trip
SELECT a.actor_id AS 'Actor ID', a.first_name AS 'First Name', a.last_name AS 'Last Name'
FROM actor a
WHERE a.actor_id IN (
    SELECT fa.actor_id 
    FROM film_actor fa
    WHERE fa.film_id = (
        SELECT f.film_id 
        FROM film f  
        WHERE f.title = 'Alone Trip'
    )
);

-- 8.•	You want to run an email marketing campaign in Canada, for which you will need the names and email addresses of all Canadian customers. Use joins to retrieve this information.
SELECT c.first_name AS 'First Name', c.last_name AS 'Last Name', c.email AS 'Email'
FROM customer c
JOIN address a ON c.address_id = a.address_id
JOIN city ci ON a.city_id = ci.city_id
JOIN country co ON ci.country_id = co.country_id
WHERE co.country = 'Canada';

-- 9.Identify all movies categorized as family films.
SELECT f.film_id AS 'Film ID', f.title AS 'Title'
FROM film f
JOIN film_category fc ON f.film_id = fc.film_id
JOIN category c ON fc.category_id = c.category_id
WHERE c.name = 'Family';

-- 10.Display the most frequently rented movies in descending order.
SELECT f.film_id, f.title, COUNT(*) AS rental_count
FROM rental r
JOIN inventory i ON i.inventory_id = r.inventory_id
JOIN film f ON i.film_id = f.film_id
GROUP BY f.film_id
ORDER BY rental_count DESC;

-- 11.Write a query to display how much business, in dollars, each store brought in.
SELECT s.store_id AS 'Store ID', SUM(p.amount) AS 'Total revenue', CONCAT(a.address, ',' , a.district, ',', ci.city, ' ', a.postal_code, ',',co.country) 'Address'
FROM payment p
JOIN customer cu ON p.customer_id = cu.customer_id
JOIN store s ON s.store_id = cu.store_id
JOIN address a ON a.address_id = s.address_id
JOIN city ci ON ci.city_id = a.city_id
JOIN country co ON ci.country_id = co.country_id
GROUP BY s.store_id;

 