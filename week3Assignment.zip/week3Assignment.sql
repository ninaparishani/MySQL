

-- 1. •	What query would you run to list the first and last names of the 5 customers who have the highest number(count) of payments? You can title the number of payments as num_payments.
use sakila;
SELECT c.first_name, c.last_name, COUNT(p.payment_id) AS num_payments
FROM customer c
JOIN payment p 
ON c.customer_id = p.customer_id
GROUP BY c.customer_id
ORDER BY num_payments DESC
LIMIT 5;


-- 2.•	What query would you run to get the customer_id associated with all payments greater than twice the average payment amount? (HINT: use 2* in your query to get twice the amount). Your result should include the customer id and the amount.
use sakila;
SELECT customer_id, amount
From payment 
WHERE amount>2*(SELECT avg(amount) FROM payment);


-- 3. •	What query would you run if your company wants to run analysis on the country data of the world database to determine the size of the countries. They have asked you to create a query that categorizes countries based on the following criteria: If a country has a population under 100,000, it is small.If a country has a population between 100,000 and 500,000, it is medium.In all other cases, the country is large.
use world;
SELECT 
    Code, Name AS country_name, population,
    CASE
        WHEN population < 100000 THEN 'small'
        WHEN population BETWEEN 100000 AND 500000 THEN 'medium'
        ELSE 'large'
    END AS size_category
FROM 
    country;
    
    
    -- 4. •	Transactions assignment: Please perform below task on any database either (World or Sakila)Create the animals tableCREATE TABLE animals (id int primary key, name varchar(255));Empty the animals table by using the TRUNCATE command, as follows:TRUNCATE TABLE animals;Use the BEGIN statement to start a transactionNow, add a record to the animals table using INSERT commandUse ROLLBACK to undo all the changes to the point where you started the transaction
    
    use sakila;
    CREATE TABLE IF NOT EXISTS animals (
    id INT PRIMARY KEY,
    name VARCHAR(255)
);
    TRUNCATE TABLE animals;
    BEGIN;
    INSERT INTO animals (id, name) VALUES (1, 'dog');
    INSERT INTO animals (id, name) VALUES (2, 'Giraffe');
	INSERT INTO animals (id, name) VALUES (3, 'Zebra');
    SELECT * FROM animals;
    ROLLBACK;
    SELECT * FROM animals;








