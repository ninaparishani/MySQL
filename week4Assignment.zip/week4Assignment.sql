USE Sakila;

-- Question 1: Build a query and save it as a view which displays all rentals, 
-- with surname of the customer and of the employee who gave the film and the store 
-- to which the employee belongs, assigning to each field a nickname. 
-- Then build another query which takes data from this view (not from the original tables, 
-- thus use the nicknames) and joining it with table employees again, 
-- display also the surname of the responsible of the store, everything sorted by employee’s surname

-- Step 1: Create the view
CREATE OR REPLACE VIEW rental_details AS
SELECT 
    r.rental_id AS RentalId,
    c.last_name AS CustomerSurname,
    s.last_name AS EmployeeSurname,
    st.store_id AS StoreId
FROM rental r
JOIN customer c ON r.customer_id = c.customer_id
JOIN staff s ON r.staff_id = s.staff_id
JOIN store st ON s.store_id = st.store_id;


-- Step 2: Query from the view and display also the surname of the responsible of the store, 
-- everything sorted by employee’s surname
SELECT 
    rd.RentalId,
    rd.CustomerSurname,
    rd.EmployeeSurname,
    rd.StoreId,
    sm.last_name AS StoreManagerSurname
FROM rental_details rd
JOIN store st ON rd.StoreId = st.store_id
JOIN staff sm ON st.manager_staff_id = sm.staff_id
ORDER BY rd.EmployeeSurname;    -- all the employees have the same surname in the result, they should be ordered by another column like 'RentalId' to get better result.




-- Question 2: Generate an alter table statement for the rental table so that an error will be raised 
-- if a row having a value found in the rental.customer_id column is deleted from the customer table.

-- Step 1: Drop the foreign key if it exists
ALTER TABLE rental
DROP FOREIGN KEY fk_rental_customer_id;

-- Step 2: Add the foreign key constraint with ON DELETE RESTRICT
ALTER TABLE rental
ADD CONSTRAINT fk_rental_customer_id
FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
ON DELETE RESTRICT;

-- Step 3: Check existing foreign key constraints
SELECT 
    TABLE_NAME, CONSTRAINT_NAME, COLUMN_NAME,
    REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'rental' AND CONSTRAINT_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME = 'customer';


-- Question 3: Create a multicolumn index on the payment tablepayment
-- Step 1: Drop the existing index
DROP INDEX idx_payment_customer_date_amount ON payment;

-- Step 2: Create the new index
CREATE INDEX idx_payment_customer_date_amount ON payment (customer_id, payment_date, amount);

-- Step 3: Show all indexes from the payment table
SHOW INDEX FROM payment;

-- Question 4: Drop the existing view if it exists and create a view with total payments by country
-- Step 1: Create the view
DROP VIEW IF EXISTS country_payments;

-- or I can use CREATE OR REPLACE VIEW country_payments AS 
CREATE VIEW country_payments AS
SELECT 
    co.country AS country_name,
    (
        SELECT SUM(p.amount)
        FROM payment p
        JOIN rental r ON p.rental_id = r.rental_id
        JOIN customer c ON r.customer_id = c.customer_id
        JOIN address a ON c.address_id = a.address_id
        JOIN city ci ON a.city_id = ci.city_id
        WHERE ci.country_id = co.country_id
    ) AS tot_payments
FROM country co;
-- Step 2: Query the view to display the results 
SELECT * FROM country_payments;

-- Question 5: List all indexes in the Sakila schema. Include the table names.
SELECT 
    table_name, 
    index_name 
FROM information_schema.statistics
WHERE table_schema = 'sakila';

-- Question 6: create all of the indexes on the sakila.customer table. . Output should be of the form:
-- "ALTER TABLE <table_name> ADD INDEX <index_name> (<column_list>)"


SELECT 
    CONCAT('ALTER TABLE ', table_name, ' ADD INDEX ', index_name, ' (', GROUP_CONCAT(column_name ORDER BY seq_in_index), ');') AS IndexCreation
FROM information_schema.statistics
WHERE table_schema = 'sakila' AND table_name = 'customer'
GROUP BY index_name;
